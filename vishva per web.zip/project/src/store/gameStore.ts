import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface GameState {
  highScore: number;
  setHighScore: (score: number) => void;
  gameSpeed: number;
  setGameSpeed: (speed: number) => void;
  isPaused: boolean;
  togglePause: () => void;
}

export const useGameStore = create<GameState>()(
  persist(
    (set) => ({
      highScore: 0,
      setHighScore: (score) => set((state) => ({
        highScore: score > state.highScore ? score : state.highScore
      })),
      gameSpeed: 100,
      setGameSpeed: (speed) => set({ gameSpeed: speed }),
      isPaused: false,
      togglePause: () => set((state) => ({ isPaused: !state.isPaused })),
    }),
    {
      name: 'game-storage',
    }
  )
);